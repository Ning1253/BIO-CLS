from itertools import permutations
from trace_time import trace_time
for i in range(25):
    
    perms = list(permutations("acdefghijklmnopqrstuvwxyz"[:i]))
    
    
    def is_pat(s):
        if len(s) == 1:
            return True
        for letter in range(1,len(s)):
            p1 = s[:letter]
            p2 = s[letter:]
            if sorted(p2)[-1]<sorted(p1)[0]:
                if is_pat(p1[::-1]) and is_pat(p2[::-1]):
                    return True
        return False

    pats = [pat for pat in perms if is_pat(pat)]
    print(len(pats))