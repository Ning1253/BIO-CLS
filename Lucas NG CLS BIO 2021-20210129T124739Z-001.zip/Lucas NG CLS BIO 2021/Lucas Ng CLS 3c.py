from itertools import cycle
from collections import deque

aim = list(input())
aim = [ord(i)-64 for i in aim]

window = deque([deque([1])])


def add(window):
    global aim
    next_w = window.copy()
    if len(next_w) < len(aim):
        next_w.append(len(next_w)+1)
        return next_w
    else: return next_w

def swap(window):
    next_w = window.copy()
    next_w.rotate(-1)
    tempStore = next_w.pop()
    next_w.rotate(-1)
    next_w.appendleft(tempStore)
    next_w.rotate(1)
    return next_w

def rotate(window):
    next_w = window.copy()
    next_w.rotate(-1)
    return next_w

history = []
from trace_time import trace_time
@trace_time
def operation():
    global window
    global history

    #print(window)
    windowADD = [add(w) for w in window]
    #print(window)
    windowSWAP = [swap(w) for w in window]
    #print(window)
    windowROT = [rotate(w) for w in window]
    #print(window)
    window = windowADD + windowSWAP + windowROT
    #print(window)
    
    withoutHist = []
    [withoutHist.append(x) for x in window if x not in history]
    window = withoutHist
    [history.append(x) for x in window if x not in history]
    

counter = 1
while deque(aim) not in window:
    operation()
    counter += 1


routes = window.count(deque(aim))

print(routes)
