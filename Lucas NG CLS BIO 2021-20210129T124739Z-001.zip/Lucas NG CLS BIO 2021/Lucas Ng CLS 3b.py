from itertools import cycle
from collections import deque
from itertools import permutations

aToE = permutations("ABCDE")

for perm in aToE:

    aim = perm
    aim = [ord(i)-64 for i in aim]

    window = deque([deque([1])])


    def add(window):
        global aim
        next_w = window.copy()
        if len(next_w) < len(aim):
            next_w.append(len(next_w)+1)
            return next_w
        else: return next_w

    def swap(window):
        next_w = window.copy()
        next_w.rotate(-1)
        tempStore = next_w.pop()
        next_w.rotate(-1)
        next_w.appendleft(tempStore)
        next_w.rotate(1)
        return next_w

    def rotate(window):
        next_w = window.copy()
        next_w.rotate(-1)
        return next_w

    history = []
    def operation():
        global window
        global history

        windowADD = [add(w) for w in window]
        windowSWAP = [swap(w) for w in window]
        windowROT = [rotate(w) for w in window]
        window = windowADD + windowSWAP + windowROT

        withoutDupes = []
        [withoutDupes.append(x) for x in window if x not in withoutDupes and x not in history]
        window = withoutDupes

        [history.append(x) for x in window]
        

    counter = 1
    while deque(aim) not in window:
        operation()
        counter += 1
    if counter==6:
        print("".join(perm))
