s1, s2 = input().split(' ')
s1 = [ord(letter) - 64 for letter in s1]
s2 = [ord(letter) - 64 for letter in s2]

def is_pat(s):
    if len(s) == 1:
        return True
    for letter in range(1,len(s)):
        p1 = s[:letter]
        p2 = s[letter:]
        if sorted(p2)[-1]<sorted(p1)[0]:
            if is_pat(p1[::-1]) and is_pat(p2[::-1]):
                return True
    return False

def output(b):
    if b:
        print("YES")
    else: print("NO")   

output(is_pat(s1))
output(is_pat(s2))
output(is_pat(s1+s2))