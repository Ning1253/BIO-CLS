perms = "ABCD BACD CABD ACBD BCAD CBAD DBAC BDAC ADBC DABC BADC ABDC ACDB CADB DACB ADCB CDAB DCAB DCBA CDBA BDCA DBCA CBDA BCDA"
perms = perms.split(" ")

def is_pat(s):
    if len(s) == 1:
        return True
    for letter in range(1,len(s)):
        p1 = s[:letter]
        p2 = s[letter:]
        if sorted(p2)[-1]<sorted(p1)[0]:
            if is_pat(p1[::-1]) and is_pat(p2[::-1]):
                return True
    return False

pats = [pat for pat in perms if is_pat(pat)]
print(pats)