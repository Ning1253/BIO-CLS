from collections import deque
def search(word,target):
    queue = deque()
    queue.append(("",0))
    seen=set()
    while len(queue) > 0:
        val,depth = queue.popleft()
        if val not in seen:
            seen.add(val)
            if val == target:
                return depth
            for x in options(val,word):
                queue.append((x,depth+1))

def options(word,avail):
    op=[]
    #adding
    if len(word) < len(avail):
        diff = len(word)-len(avail)
        avail = avail[diff:]
        for el in avail:
            op.append(word+el)
    #swapping
    if len(word) >= 2:
        op.append(word[1]+word[0]+word[2:])
        #rotate
        op.append(word[1:]+word[0])
    return op

def wrap(target):
    return search("".join(sorted(target)),target)

if __name__ == "__main__":
    from itertools import permutations
    LIST = ("".join(elem) for elem in permutations("ABCDE"))
    n=[]
    s=[]
    for opt in LIST:
        if wrap(opt)>=6:
            n.append(opt)
        else:
            s.append(opt)
    print("6+ ",n,len(n))
    print("="*20)
    print("5- ",s,len(s))