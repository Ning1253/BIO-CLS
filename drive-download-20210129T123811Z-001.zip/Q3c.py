from collections import deque
def search(word,target):
    n=0
    queue = deque()
    queue.append(("",0))
    seen=set()
    while len(queue) > 0:
        val,depth = queue.popleft()
        if val not in seen:
            seen.add(val)
            if depth > 24:
                return n
            if val == target:
                if depth < 25:
                    n+=1
            for x in options(val,word):
                queue.append((x,depth+1))

def options(word,avail):
    op=[]
    #adding
    if len(word) < len(avail):
        diff = len(word)-len(avail)
        avail = avail[diff:]
        for el in avail:
            op.append(word+el)
    #swapping
    if len(word) >= 2:
        op.append(word[1]+word[0]+word[2:])
        #rotate
        op.append(word[1:]+word[0])
    return op

def wrap(target):
    return search("".join(sorted(target)),target)

if __name__ == "__main__":
    print(wrap("HGFEDCBA"))