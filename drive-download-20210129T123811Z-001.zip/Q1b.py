alph = "abcdefghijklmnopqrstuvwxyz".upper()
def bigger(a,b): return min([alph.find(x) for x in a]) > max([alph.find(x) for x in b])

def pat(word):
    if len(word) == 1:
        return True
    for option in range(1,len(word)):
        left,right = word[:option],word[option:]
        left,right = "".join(reversed(left)),"".join(reversed(right))
        if bigger(left,right):
            if pat(left) and pat(right):
                return True
    return False


from itertools import permutations

for L in range(len(alph)):
    k=alph[:L]
    print(k)
    X = permutations(k)
    n=0
    for elem in X:
        elem = "".join(elem)
        if pat(elem):
            n+=1
    print(n)