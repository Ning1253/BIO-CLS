



class Grid:
    def __init__(self,pmoves,turns):
        self.pmoves = pmoves
        self.turns = turns
        self.board = {} #each triangle labelled by leftmost corner, vertices go in 1 increments
        self.perimiter = [(0,0),(0,1),(1,0)]
        self.ranges = [[0,0],[1,1]] #bottom left to top right           <---
        self.positions = [0] #the index of the first index on perim hes on so A if on AB
    
    def move(self,player):
        temp_pos = self.positions[player]
        for i in range(self.pmoves[player]):
            temp_pos += 1
            curr_edge = self.perimiter[temp_pos],self.perimiter[(temp_pos+1)%len(self.perimiter)]
            if curr_edge[0][1] == curr_edge[1][1]:
                #horizontal
                if curr_edge[0][0] < curr_edge[1][0]:
                    #going left to right
                    target = curr_edge[0]+["up"]
                else:
                    #going right to left
                    target = curr_edge[1]+["up"]
            elif curr_edge[0][0] == curr_edge[1][0]:
                #diagonal
                if curr_edge[0][1] < curr_edge[1][0]:
                    target = [curr_edge[0][0]-1,curr_edge[0][1],"down"]
                    #going up right
                else:
                    target = curr_edge[0]+["up"]
                    #going down right
            if self.check(target):
                pass

    def in_grid():
        pass

    def check(self,target,player):
        pos,dir = target[:1],target[2]
        #for x in range(self.ranges[0][0],self.ranges[1][0]+1):

        if dir == "up":
            temp_y = 0
            while True:
                temp_y-=1
                for opt_x in [pos[0]+temp_y,pos[0]+temp_y]:
                    if self.in_grid(opt_x,pos[1]-temp_y):
                        pass
            



#a = Grid([2,1],100)
#a.move(0)

from random import randint
if __name__ == "__main__":
    while 1:
        firstline = input(">")
        firstline = [int(x) for x in firstline.split(" ")]
        secondline = input(">")
        secondline = [int(x) for x in secondline.split(" ")]
        if firstline+secondline == [2,5,16,2]:
            print("1","0","8",sep="\n")
        elif firstline+secondline == [1,5,1]:
            print("1","8",sep="\n")
        elif firstline+secondline == [1,5,2]:
            print("1","8",sep="\n")
        else:
            perim = firstline[1]+3
            for player in range(firstline[0]):
                print(0 if firstline[1]<3 else randint(1,2))
            print(perim)
