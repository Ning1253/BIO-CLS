

alph = "abcdefghijklmnopqrstuvwxyz".upper()
def bigger(a,b): return min([alph.find(x) for x in a]) > max([alph.find(x) for x in b])

def pat(word):
    if len(word) == 1:
        return True
    for option in range(1,len(word)):
        left,right = word[:option],word[option:]
        left,right = "".join(reversed(left)),"".join(reversed(right))
        if bigger(left,right):
            if pat(left) and pat(right):
                return True
    return False

def wrap():
    words = input(">")
    words = words.split()
    assert len(words) == 2
    for word in (words[0],words[1],"".join(words)):
        print(("NO","YES")[pat(word)])


if __name__ == "__main__":
    print("Alexandre Noel - City of London School")
    while 1:
        wrap()

from itertools import permutations

for L in range(len(alph)):
    k=alph[:L]
    print(k)
    X = permutations(k)
    n=0
    for elem in X:
        elem = "".join(elem)
        if pat(elem):
            n+=1
    print(n)